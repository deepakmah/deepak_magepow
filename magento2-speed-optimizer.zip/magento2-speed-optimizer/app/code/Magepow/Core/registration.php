<?php

/**
 * @Author: nguyen
 * @Date:   2020-02-17 13:58:49
 * @Last Modified by:   Alex Dong
 * @Last Modified time: 2020-04-15 19:40:24
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magepow_Core',
    __DIR__
);
