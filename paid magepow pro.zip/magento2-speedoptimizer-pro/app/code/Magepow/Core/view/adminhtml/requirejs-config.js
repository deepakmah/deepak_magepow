var config = {

	paths: {
		'magepow/feed'	: 'Magepow_Core/js/feed',
	},

	shim: {
		'magepow/feed': {
			deps: ['jquery', 'magepow/slick']
		}
	}

};