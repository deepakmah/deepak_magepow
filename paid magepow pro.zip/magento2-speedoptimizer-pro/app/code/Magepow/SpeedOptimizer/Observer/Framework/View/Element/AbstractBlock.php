<?php

/**
 * @Author: nguyen
 * @Date:   2020-05-09 23:33:09
 * @Last Modified by:   Alex Dong
 * @Last Modified time: 2021-07-22 17:18:17
 */

namespace Magepow\SpeedOptimizer\Observer\Framework\View\Element;

use Magento\Framework\Event\ObserverInterface;
use Magepow\SpeedOptimizer\Plugin\SpeedOptimizer;

class AbstractBlock extends SpeedOptimizer implements ObserverInterface
{

    protected $excludeBlock;

    public function execute(\Magento\Framework\Event\Observer $observer )
    {

        if( !$this->helper->getConfigModule('general/enabled') ) return;

        if($this->request->isXmlHttpRequest()){
            /* request is ajax */
            $lazyAjax = $this->helper->getConfigModule('general/lazy_ajax');
            if( !$lazyAjax ) return;
            $contentType = $response->getHeader('Content-Type');
            if( $contentType && $contentType->getMediaType() == 'application/json' ) {
                $this->isJson = true;
                // return; // break response type json
            }
        }

        $excludeBlock = $this->helper->getConfigModule('general/exclude_block');
        // $exclude = 'product-image-photo';
        if($excludeBlock){
            $excludeBlock = str_replace(' ', '', $excludeBlock);
            // $this->excludeBlock = array_map('trim', explode(',', $excludeBlock));
            $this->excludeBlock = array_map('trim', explode(PHP_EOL, $excludeBlock));
        }
        $block = $observer->getData('block');
        $class = get_class($block);
        $class = preg_replace('/\b\\\Interceptor$/', '', $class);
        if( !$this->excludeBlock || !in_array($class, $this->excludeBlock) ){
            $transport = $observer->getData('transport');
            $html      = $transport->getHtml();
            $html      = $this->optimizerHtml($html);
            $transport->setHtml($html);
        }

        return $this;
    }
    /**
     * @param string
     * @return string
     */
    public function optimizerHtml($blockHtml)
    {

        $minifyHtml = $this->helper->getConfigModule('general/minify_html');
        $minifyJs   = $this->helper->getConfigModule('general/minify_js');
        $blockHtml  = $this->processExcludeJs($blockHtml, $minifyJs);
        if($minifyHtml) $blockHtml = $this->minifyHtml($blockHtml);

        $loadingImg  = $this->helper->getConfigModule('general/loading_img');
        if($loadingImg){
            $exclude = $this->helper->getConfigModule('general/exclude_img');
            if($exclude){
                $exclude = str_replace(' ', '', $exclude);
                $this->exclude = explode(',', $exclude);
            }
            $placeholder = $this->helper->getConfigModule('general/placeholder');
            $blockHtml = $this->addLazyload($blockHtml, $placeholder);             
        }

        $blockHtml = preg_replace_callback(
            '~<\s*\bscript\b[^>]*>(.*?)<\s*\/\s*script\s*>~is',
            function($match){
                $scriptId = trim($match[1], ' ');
                if($scriptId && isset($this->scripts[$scriptId])){
                    return $this->scripts[$scriptId];
                }else {
                    return $match[0];
                }
            },
            $blockHtml
        );

        return $blockHtml;
    }

}
