<?php
namespace Magepow\SpeedOptimizer\Plugin;

class UserAgentContext
{
    /**
    * @var \Magento\Framework\HTTP\Header
    */
    protected $httpHeader;

    /**
 	* @var \Magento\Framework\App\Http\Context
 	*/
    protected $httpContext;

    /**
 	* @param \Magento\Framework\HTTP\Header $httpHeader
 	* @param \Magento\Framework\App\Http\Context $httpContext
 	*/
    public function __construct(
    	\Magento\Framework\HTTP\Header $httpHeader,
    	\Magento\Framework\App\Http\Context $httpContext
    ) {
    	$this->httpHeader = $httpHeader;
    	$this->httpContext = $httpContext;
    }

    /**
 	* @param \Magento\Framework\App\ActionInterface $subject
 	* @param callable $proceed
 	* @param \Magento\Framework\App\RequestInterface $request
 	* @return mixed
 	*/
    public function aroundDispatch(
    	\Magento\Framework\App\ActionInterface $subject,
    	\Closure $proceed,
    	\Magento\Framework\App\RequestInterface $request
    ) {
    	$this->httpContext->setValue(
        	'user_agent',
        	$this->httpHeader->getHttpUserAgent(),
        	false
    	);

    	return $proceed($request);
    }
}