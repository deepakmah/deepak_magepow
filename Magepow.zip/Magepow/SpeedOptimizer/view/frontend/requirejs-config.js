var config = {

	paths: {
		'magepow/lazyload'			: 'Magepow_SpeedOptimizer/js/plugin/lazyload.min',
	},

	shim: {
		'magepow/lazyload': {
			deps: ['jquery']
		}
	}

};
